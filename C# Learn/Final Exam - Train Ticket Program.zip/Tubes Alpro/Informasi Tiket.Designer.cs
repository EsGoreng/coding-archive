﻿namespace Tubes_Alpro
{
    partial class informasi_tiket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            label4 = new Label();
            asal = new Label();
            akhir = new Label();
            tanggal = new Label();
            penumpang = new Label();
            kode = new Label();
            label10 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(139, 208);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 0;
            button1.Text = "Cetak Tiket";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(100, 33);
            label1.Name = "label1";
            label1.Size = new Size(95, 20);
            label1.TabIndex = 1;
            label1.Text = "Stasiun Asal :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(94, 62);
            label2.Name = "label2";
            label2.Size = new Size(101, 20);
            label2.TabIndex = 2;
            label2.Text = "Stasiun Akhir :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 91);
            label3.Name = "label3";
            label3.Size = new Size(172, 20);
            label3.TabIndex = 3;
            label3.Text = "Tanggal Keberangkatan :";
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(51, 120);
            label4.Name = "label4";
            label4.Size = new Size(144, 20);
            label4.TabIndex = 4;
            label4.Text = "Jumlah Penumpang :";
            // 
            // asal
            // 
            asal.AutoSize = true;
            asal.Location = new Point(192, 33);
            asal.Name = "asal";
            asal.Size = new Size(55, 20);
            asal.TabIndex = 5;
            asal.Text = "(blank)";
            // 
            // akhir
            // 
            akhir.AutoSize = true;
            akhir.Location = new Point(192, 62);
            akhir.Name = "akhir";
            akhir.Size = new Size(55, 20);
            akhir.TabIndex = 6;
            akhir.Text = "(blank)";
            // 
            // tanggal
            // 
            tanggal.AutoSize = true;
            tanggal.Location = new Point(192, 91);
            tanggal.Name = "tanggal";
            tanggal.Size = new Size(55, 20);
            tanggal.TabIndex = 7;
            tanggal.Text = "(blank)";
            // 
            // penumpang
            // 
            penumpang.AutoSize = true;
            penumpang.Location = new Point(192, 120);
            penumpang.Name = "penumpang";
            penumpang.Size = new Size(55, 20);
            penumpang.TabIndex = 8;
            penumpang.Text = "(blank)";
            // 
            // kode
            // 
            kode.AutoSize = true;
            kode.Location = new Point(192, 149);
            kode.Name = "kode";
            kode.Size = new Size(55, 20);
            kode.TabIndex = 10;
            kode.Text = "(blank)";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(108, 149);
            label10.Name = "label10";
            label10.Size = new Size(87, 20);
            label10.TabIndex = 9;
            label10.Text = "Kode Tiket :";
            // 
            // informasi_tiket
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(370, 249);
            Controls.Add(kode);
            Controls.Add(label10);
            Controls.Add(penumpang);
            Controls.Add(tanggal);
            Controls.Add(akhir);
            Controls.Add(asal);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            MaximizeBox = false;
            Name = "informasi_tiket";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Informasi Tiket";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private Label label4;
        private Label label10;
        public Label asal;
        public Label akhir;
        public Label tanggal;
        public Label penumpang;
        public Label kode;
    }
}