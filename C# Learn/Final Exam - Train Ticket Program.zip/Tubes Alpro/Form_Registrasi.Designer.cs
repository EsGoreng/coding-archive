﻿namespace Tubes_Alpro
{
    partial class menu_registrasi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            passReg_textBox = new TextBox();
            label2 = new Label();
            userReg_textBox = new TextBox();
            label1 = new Label();
            button_submit = new Button();
            nama_textBox = new TextBox();
            label3 = new Label();
            email_textBox = new TextBox();
            label4 = new Label();
            nohp_textBox = new TextBox();
            label6 = new Label();
            button_back = new Button();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.CheckAlign = ContentAlignment.MiddleRight;
            checkBox1.Location = new Point(210, 296);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(132, 24);
            checkBox1.TabIndex = 6;
            checkBox1.Text = "Show Password";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // passReg_textBox
            // 
            passReg_textBox.Location = new Point(109, 263);
            passReg_textBox.Name = "passReg_textBox";
            passReg_textBox.Size = new Size(233, 27);
            passReg_textBox.TabIndex = 5;
            passReg_textBox.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(28, 266);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 0;
            label2.Text = "Password";
            // 
            // userReg_textBox
            // 
            userReg_textBox.Location = new Point(109, 230);
            userReg_textBox.Name = "userReg_textBox";
            userReg_textBox.Size = new Size(233, 27);
            userReg_textBox.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 233);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // button_submit
            // 
            button_submit.Location = new Point(146, 352);
            button_submit.Name = "button_submit";
            button_submit.Size = new Size(196, 29);
            button_submit.TabIndex = 8;
            button_submit.Text = "Submit";
            button_submit.UseVisualStyleBackColor = true;
            button_submit.Click += button1_Click;
            // 
            // nama_textBox
            // 
            nama_textBox.Location = new Point(109, 131);
            nama_textBox.Name = "nama_textBox";
            nama_textBox.Size = new Size(233, 27);
            nama_textBox.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(28, 134);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 5;
            label3.Text = "Nama";
            // 
            // email_textBox
            // 
            email_textBox.Location = new Point(109, 164);
            email_textBox.Name = "email_textBox";
            email_textBox.Size = new Size(233, 27);
            email_textBox.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(28, 167);
            label4.Name = "label4";
            label4.Size = new Size(46, 20);
            label4.TabIndex = 7;
            label4.Text = "Email";
            // 
            // nohp_textBox
            // 
            nohp_textBox.Location = new Point(109, 197);
            nohp_textBox.Name = "nohp_textBox";
            nohp_textBox.Size = new Size(233, 27);
            nohp_textBox.TabIndex = 3;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(28, 200);
            label6.Name = "label6";
            label6.Size = new Size(55, 20);
            label6.TabIndex = 9;
            label6.Text = "No. HP";
            // 
            // button_back
            // 
            button_back.Location = new Point(28, 352);
            button_back.Name = "button_back";
            button_back.Size = new Size(112, 29);
            button_back.TabIndex = 7;
            button_back.Text = "Back";
            button_back.UseVisualStyleBackColor = true;
            button_back.Click += button2_Click;
            // 
            // menu_registrasi
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(373, 413);
            Controls.Add(button_back);
            Controls.Add(nohp_textBox);
            Controls.Add(label6);
            Controls.Add(email_textBox);
            Controls.Add(label4);
            Controls.Add(nama_textBox);
            Controls.Add(label3);
            Controls.Add(button_submit);
            Controls.Add(checkBox1);
            Controls.Add(passReg_textBox);
            Controls.Add(label2);
            Controls.Add(userReg_textBox);
            Controls.Add(label1);
            Name = "menu_registrasi";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tubes Alpro - Registrasi Akun";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private TextBox passReg_textBox;
        private Label label2;
        private TextBox userReg_textBox;
        private Label label1;
        private Button button_submit;
        private TextBox nama_textBox;
        private Label label3;
        private TextBox email_textBox;
        private Label label4;
        private TextBox nohp_textBox;
        private Label label6;
        private Button button_back;
    }
}