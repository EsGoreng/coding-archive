﻿namespace Tubes_Alpro
{
    partial class menu_utama
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            user_textBox = new TextBox();
            login_button = new Button();
            pass_textBox = new TextBox();
            label2 = new Label();
            linkLabel1 = new LinkLabel();
            cancel_button = new Button();
            checkBox1 = new CheckBox();
            register_button = new Button();
            richTextBox1 = new RichTextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 179);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // user_textBox
            // 
            user_textBox.Location = new Point(93, 176);
            user_textBox.Name = "user_textBox";
            user_textBox.Size = new Size(222, 27);
            user_textBox.TabIndex = 1;
            // 
            // login_button
            // 
            login_button.Location = new Point(66, 281);
            login_button.Name = "login_button";
            login_button.Size = new Size(94, 29);
            login_button.TabIndex = 4;
            login_button.Text = "Login";
            login_button.UseVisualStyleBackColor = true;
            login_button.Click += login_button_Click;
            // 
            // pass_textBox
            // 
            pass_textBox.Location = new Point(93, 209);
            pass_textBox.Name = "pass_textBox";
            pass_textBox.Size = new Size(222, 27);
            pass_textBox.TabIndex = 2;
            pass_textBox.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 212);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(22, 366);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(125, 20);
            linkLabel1.TabIndex = 6;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Forgot Password?";
            // 
            // cancel_button
            // 
            cancel_button.Location = new Point(66, 316);
            cancel_button.Name = "cancel_button";
            cancel_button.Size = new Size(194, 29);
            cancel_button.TabIndex = 5;
            cancel_button.Text = "Cancel";
            cancel_button.UseVisualStyleBackColor = true;
            cancel_button.Click += cancel_button_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.CheckAlign = ContentAlignment.MiddleRight;
            checkBox1.Location = new Point(183, 242);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(132, 24);
            checkBox1.TabIndex = 3;
            checkBox1.Text = "Show Password";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // register_button
            // 
            register_button.Location = new Point(166, 281);
            register_button.Name = "register_button";
            register_button.Size = new Size(94, 29);
            register_button.TabIndex = 7;
            register_button.Text = "Register";
            register_button.UseVisualStyleBackColor = true;
            register_button.Click += register_button_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Font = new Font("COCOGOOSE", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            richTextBox1.ForeColor = SystemColors.Highlight;
            richTextBox1.Location = new Point(12, 12);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(303, 158);
            richTextBox1.TabIndex = 8;
            richTextBox1.Text = "Tubes Algoritma & Pemrograman\n\nItsna Akhdan Fadhil - Pemrograman, Database\nRafly Zulfikar - Flowchart\nDawai - Pseudocode\nTio Maria - Konsep Ide";
            // 
            // menu_utama
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(329, 406);
            Controls.Add(richTextBox1);
            Controls.Add(register_button);
            Controls.Add(checkBox1);
            Controls.Add(cancel_button);
            Controls.Add(linkLabel1);
            Controls.Add(pass_textBox);
            Controls.Add(label2);
            Controls.Add(login_button);
            Controls.Add(user_textBox);
            Controls.Add(label1);
            Name = "menu_utama";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tubes Alpro - Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox user_textBox;
        private Button login_button;
        private TextBox pass_textBox;
        private Label label2;
        private LinkLabel linkLabel1;
        private Button cancel_button;
        private CheckBox checkBox1;
        private Button register_button;
        private RichTextBox richTextBox1;
    }
}
