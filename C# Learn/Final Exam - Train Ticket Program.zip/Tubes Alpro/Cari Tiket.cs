﻿using Microsoft.Data.SqlClient;

namespace Tubes_Alpro
{
    public partial class cari_tiket : Form
    {
        public cari_tiket()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            textBox1.Text = treeView1.SelectedNode.Text;
        }

        private void treeView2_AfterSelect(object sender, TreeViewEventArgs e)
        {
            textBox2.Text = treeView2.SelectedNode.Text;

        }

        private void button_back_Click(object sender, EventArgs e)
        {
            menu_utama f1_0808 = new menu_utama();
            f1_0808.Show();
            Visible = false;
        }

        private void button_cari_tiket_Click(object sender, EventArgs e)
        {
            SqlConnection con_0808 = new SqlConnection("Data Source=LAPTOP-3AFPOK6N;Initial Catalog=loginapp;Integrated Security=True;Trust Server Certificate=True");
            con_0808.Open();
            string query_0808 = "SELECT COUNT(*) FROM RelasiStasiun WHERE StasiunAsal =@asal AND StasiunTujuan =@tujuan";
            SqlCommand cmd_0808 = new SqlCommand(query_0808, con_0808);
            cmd_0808.Parameters.AddWithValue("@asal", treeView1.SelectedNode.Text);
            cmd_0808.Parameters.AddWithValue("@tujuan", treeView2.SelectedNode.Text);
            object result_0808 = cmd_0808.ExecuteScalar();
            con_0808.Close();
            if (result_0808 != null && Convert.ToInt32(result_0808) > 0)
            {
                MessageBox.Show("Tiket Tersedia !!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);

                string stasiun_asal_0808 = treeView1.SelectedNode.Text;
                string stasiun_tujuan_0808 = treeView2.SelectedNode.Text;
                DateTime tanggalTerpilih_0808 = dateTimePicker1.Value;
                string tanggalString_0808 = tanggalTerpilih_0808.ToString("dd MMMM yyyy");
                string jumlah_0808 = Convert.ToString(numericUpDown1.Value);
                Random random_0808 = new Random();
                int angkaRandom_0808 = random_0808.Next(1, 100001);
                string angkaString_0808 = Convert.ToString(angkaRandom_0808);

                informasi_tiket f4_0808 = new informasi_tiket
                    (
                    stasiun_asal_0808,
                    stasiun_tujuan_0808,
                    tanggalString_0808,
                    jumlah_0808,
                    angkaString_0808
                    );

                f4_0808.asal.Text = stasiun_asal_0808;
                f4_0808.akhir.Text = stasiun_tujuan_0808;
                f4_0808.tanggal.Text = tanggalString_0808;
                f4_0808.penumpang.Text = jumlah_0808;
                f4_0808.kode.Text = angkaString_0808;

                f4_0808.Show();

            }
            else
            {
                MessageBox.Show("Tiket Tidak Tersedia !!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime tanggal_Keberangkatan_0808 = dateTimePicker1.Value;
        }   
    }
}
