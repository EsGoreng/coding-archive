﻿namespace Tubes_Alpro
{
    partial class cari_tiket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cari_tiket));
            TreeNode treeNode1 = new TreeNode("Stasiun Bandung");
            TreeNode treeNode2 = new TreeNode("Stasiun Kiaracondong");
            TreeNode treeNode3 = new TreeNode("Kota Bandung", new TreeNode[] { treeNode1, treeNode2 });
            TreeNode treeNode4 = new TreeNode("Stasiun Padalarang");
            TreeNode treeNode5 = new TreeNode("Kabupaten Bandung Barat", new TreeNode[] { treeNode4 });
            TreeNode treeNode6 = new TreeNode("Stasiun Rancaekek");
            TreeNode treeNode7 = new TreeNode("Stasiun Cicalengka");
            TreeNode treeNode8 = new TreeNode("Kabupaten Bandung", new TreeNode[] { treeNode6, treeNode7 });
            TreeNode treeNode9 = new TreeNode("Stasiun Cimahi");
            TreeNode treeNode10 = new TreeNode("Kota Cimahi", new TreeNode[] { treeNode9 });
            TreeNode treeNode11 = new TreeNode("Stasiun Cianjur");
            TreeNode treeNode12 = new TreeNode("Stasiun Ciranjang");
            TreeNode treeNode13 = new TreeNode("Stasiun Lampengan");
            TreeNode treeNode14 = new TreeNode("Kabupaten Cianjur", new TreeNode[] { treeNode11, treeNode12, treeNode13 });
            TreeNode treeNode15 = new TreeNode("Stasiun Garut");
            TreeNode treeNode16 = new TreeNode("Stasiun Cibatu");
            TreeNode treeNode17 = new TreeNode("Stasiun Karangsari");
            TreeNode treeNode18 = new TreeNode("Kabupaten Garut", new TreeNode[] { treeNode15, treeNode16, treeNode17 });
            TreeNode treeNode19 = new TreeNode("Stasiun Tasikmalaya");
            TreeNode treeNode20 = new TreeNode("Kota Tasikmalaya", new TreeNode[] { treeNode19 });
            TreeNode treeNode21 = new TreeNode("Stasiun Ciamis");
            TreeNode treeNode22 = new TreeNode("Kabupaten Ciamis", new TreeNode[] { treeNode21 });
            TreeNode treeNode23 = new TreeNode("Stasiun Banjar");
            TreeNode treeNode24 = new TreeNode("Kabupaten Banjar", new TreeNode[] { treeNode23 });
            TreeNode treeNode25 = new TreeNode("Stasiun Sukabumi");
            TreeNode treeNode26 = new TreeNode("Stasiun Cicurug");
            TreeNode treeNode27 = new TreeNode("Stasiun Cibadak");
            TreeNode treeNode28 = new TreeNode("Stasiun Parakuda");
            TreeNode treeNode29 = new TreeNode("Kabupaten Sukabumi", new TreeNode[] { treeNode25, treeNode26, treeNode27, treeNode28 });
            TreeNode treeNode30 = new TreeNode("Stasiun Purwakarta");
            TreeNode treeNode31 = new TreeNode("Kabupaten Purwakarta", new TreeNode[] { treeNode30 });
            TreeNode treeNode32 = new TreeNode("Stasiun Karawang");
            TreeNode treeNode33 = new TreeNode("Stasiun Klari");
            TreeNode treeNode34 = new TreeNode("Kabupaten Karawang", new TreeNode[] { treeNode32, treeNode33 });
            TreeNode treeNode35 = new TreeNode("Stasiun Bekasi");
            TreeNode treeNode36 = new TreeNode("Stasiun Cikarang");
            TreeNode treeNode37 = new TreeNode("Kabupaten Bekasi dan Kota Bekasi", new TreeNode[] { treeNode35, treeNode36 });
            TreeNode treeNode38 = new TreeNode("Stasiun Pagedanbaru");
            TreeNode treeNode39 = new TreeNode("Kabupaten Subang", new TreeNode[] { treeNode38 });
            TreeNode treeNode40 = new TreeNode("Stasiun Haurgeulis");
            TreeNode treeNode41 = new TreeNode("Stasiun Jatibarang");
            TreeNode treeNode42 = new TreeNode("Kabupaten Indramayu", new TreeNode[] { treeNode40, treeNode41 });
            TreeNode treeNode43 = new TreeNode("Stasiun Cikampek");
            TreeNode treeNode44 = new TreeNode("Stasiun Kadipaten");
            TreeNode treeNode45 = new TreeNode("Kabupaten Majalengka", new TreeNode[] { treeNode43, treeNode44 });
            TreeNode treeNode46 = new TreeNode("Stasiun Cirebon");
            TreeNode treeNode47 = new TreeNode("Stasiun Cirebon Pujakan");
            TreeNode treeNode48 = new TreeNode("Stasiun Babakan");
            TreeNode treeNode49 = new TreeNode("Kabupaten Cirebon", new TreeNode[] { treeNode46, treeNode47, treeNode48 });
            TreeNode treeNode50 = new TreeNode("Stasiun Bandung");
            TreeNode treeNode51 = new TreeNode("Stasiun Kiaracondong");
            TreeNode treeNode52 = new TreeNode("Kota Bandung", new TreeNode[] { treeNode50, treeNode51 });
            TreeNode treeNode53 = new TreeNode("Stasiun Padalarang");
            TreeNode treeNode54 = new TreeNode("Kabupaten Bandung Barat", new TreeNode[] { treeNode53 });
            TreeNode treeNode55 = new TreeNode("Stasiun Rancaekek");
            TreeNode treeNode56 = new TreeNode("Stasiun Cicalengka");
            TreeNode treeNode57 = new TreeNode("Kabupaten Bandung", new TreeNode[] { treeNode55, treeNode56 });
            TreeNode treeNode58 = new TreeNode("Stasiun Cimahi");
            TreeNode treeNode59 = new TreeNode("Kota Cimahi", new TreeNode[] { treeNode58 });
            TreeNode treeNode60 = new TreeNode("Stasiun Cianjur");
            TreeNode treeNode61 = new TreeNode("Stasiun Ciranjang");
            TreeNode treeNode62 = new TreeNode("Stasiun Lampengan");
            TreeNode treeNode63 = new TreeNode("Kabupaten Cianjur", new TreeNode[] { treeNode60, treeNode61, treeNode62 });
            TreeNode treeNode64 = new TreeNode("Stasiun Garut");
            TreeNode treeNode65 = new TreeNode("Stasiun Cibatu");
            TreeNode treeNode66 = new TreeNode("Stasiun Karangsari");
            TreeNode treeNode67 = new TreeNode("Kabupaten Garut", new TreeNode[] { treeNode64, treeNode65, treeNode66 });
            TreeNode treeNode68 = new TreeNode("Stasiun Tasikmalaya");
            TreeNode treeNode69 = new TreeNode("Kota Tasikmalaya", new TreeNode[] { treeNode68 });
            TreeNode treeNode70 = new TreeNode("Stasiun Ciamis");
            TreeNode treeNode71 = new TreeNode("Kabupaten Ciamis", new TreeNode[] { treeNode70 });
            TreeNode treeNode72 = new TreeNode("Stasiun Banjar");
            TreeNode treeNode73 = new TreeNode("Kabupaten Banjar", new TreeNode[] { treeNode72 });
            TreeNode treeNode74 = new TreeNode("Stasiun Sukabumi");
            TreeNode treeNode75 = new TreeNode("Stasiun Cicurug");
            TreeNode treeNode76 = new TreeNode("Stasiun Cibadak");
            TreeNode treeNode77 = new TreeNode("Stasiun Parakuda");
            TreeNode treeNode78 = new TreeNode("Kabupaten Sukabumi", new TreeNode[] { treeNode74, treeNode75, treeNode76, treeNode77 });
            TreeNode treeNode79 = new TreeNode("Stasiun Purwakarta");
            TreeNode treeNode80 = new TreeNode("Kabupaten Purwakarta", new TreeNode[] { treeNode79 });
            TreeNode treeNode81 = new TreeNode("Stasiun Karawang");
            TreeNode treeNode82 = new TreeNode("Stasiun Klari");
            TreeNode treeNode83 = new TreeNode("Kabupaten Karawang", new TreeNode[] { treeNode81, treeNode82 });
            TreeNode treeNode84 = new TreeNode("Stasiun Bekasi");
            TreeNode treeNode85 = new TreeNode("Stasiun Cikarang");
            TreeNode treeNode86 = new TreeNode("Kabupaten Bekasi dan Kota Bekasi", new TreeNode[] { treeNode84, treeNode85 });
            TreeNode treeNode87 = new TreeNode("Stasiun Pagedanbaru");
            TreeNode treeNode88 = new TreeNode("Kabupaten Subang", new TreeNode[] { treeNode87 });
            TreeNode treeNode89 = new TreeNode("Stasiun Haurgeulis");
            TreeNode treeNode90 = new TreeNode("Stasiun Jatibarang");
            TreeNode treeNode91 = new TreeNode("Kabupaten Indramayu", new TreeNode[] { treeNode89, treeNode90 });
            TreeNode treeNode92 = new TreeNode("Stasiun Cikampek");
            TreeNode treeNode93 = new TreeNode("Stasiun Kadipaten");
            TreeNode treeNode94 = new TreeNode("Kabupaten Majalengka", new TreeNode[] { treeNode92, treeNode93 });
            TreeNode treeNode95 = new TreeNode("Stasiun Cirebon");
            TreeNode treeNode96 = new TreeNode("Stasiun Cirebon Pujakan");
            TreeNode treeNode97 = new TreeNode("Stasiun Babakan");
            TreeNode treeNode98 = new TreeNode("Kabupaten Cirebon", new TreeNode[] { treeNode95, treeNode96, treeNode97 });
            pictureBox1 = new PictureBox();
            button_close = new Button();
            dateTimePicker1 = new DateTimePicker();
            groupBox1 = new GroupBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            button_cari_tiket = new Button();
            treeView2 = new TreeView();
            label4 = new Label();
            label3 = new Label();
            numericUpDown1 = new NumericUpDown();
            label2 = new Label();
            treeView1 = new TreeView();
            label1 = new Label();
            button_back = new Button();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-3, -10);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(346, 480);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button_close
            // 
            button_close.Location = new Point(21, 371);
            button_close.Name = "button_close";
            button_close.Size = new Size(94, 29);
            button_close.TabIndex = 1;
            button_close.Text = "Close";
            button_close.UseVisualStyleBackColor = true;
            button_close.Click += button1_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(15, 274);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(237, 27);
            dateTimePicker1.TabIndex = 2;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.AppWorkspace;
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button_cari_tiket);
            groupBox1.Controls.Add(treeView2);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(numericUpDown1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(treeView1);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Location = new Point(359, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(522, 432);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Pencarian Tiket";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(269, 221);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(237, 27);
            textBox2.TabIndex = 15;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(15, 221);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(237, 27);
            textBox1.TabIndex = 14;
            // 
            // button_cari_tiket
            // 
            button_cari_tiket.Location = new Point(412, 392);
            button_cari_tiket.Name = "button_cari_tiket";
            button_cari_tiket.Size = new Size(94, 29);
            button_cari_tiket.TabIndex = 13;
            button_cari_tiket.Text = "Cari Tiket";
            button_cari_tiket.UseVisualStyleBackColor = true;
            button_cari_tiket.Click += button_cari_tiket_Click;
            // 
            // treeView2
            // 
            treeView2.Location = new Point(269, 61);
            treeView2.Name = "treeView2";
            treeNode1.Name = "sts_bandung";
            treeNode1.Text = "Stasiun Bandung";
            treeNode2.Name = "sts_kiaracondong";
            treeNode2.Text = "Stasiun Kiaracondong";
            treeNode3.Name = "kota_bandung";
            treeNode3.Text = "Kota Bandung";
            treeNode4.Name = "sts_padalarang";
            treeNode4.Text = "Stasiun Padalarang";
            treeNode5.Name = "kab_bandung_barat";
            treeNode5.Text = "Kabupaten Bandung Barat";
            treeNode6.Name = "sts_rancaekek";
            treeNode6.Text = "Stasiun Rancaekek";
            treeNode7.Name = "sts_cicalengka";
            treeNode7.Text = "Stasiun Cicalengka";
            treeNode8.Name = "kab_bandung";
            treeNode8.Text = "Kabupaten Bandung";
            treeNode9.Name = "sts_cimahi";
            treeNode9.Text = "Stasiun Cimahi";
            treeNode10.Name = "kota_cimahi";
            treeNode10.Text = "Kota Cimahi";
            treeNode11.Name = "sts_cianjur";
            treeNode11.Text = "Stasiun Cianjur";
            treeNode12.Name = "sts_ciranjang";
            treeNode12.Text = "Stasiun Ciranjang";
            treeNode13.Name = "sts_lampengan";
            treeNode13.Text = "Stasiun Lampengan";
            treeNode14.Name = "kab_cianjur";
            treeNode14.Text = "Kabupaten Cianjur";
            treeNode15.Name = "sts_garut";
            treeNode15.Text = "Stasiun Garut";
            treeNode16.Name = "sts_cibatu";
            treeNode16.Text = "Stasiun Cibatu";
            treeNode17.Name = "sts_karangsari";
            treeNode17.Text = "Stasiun Karangsari";
            treeNode18.Name = "kab_garut";
            treeNode18.Text = "Kabupaten Garut";
            treeNode19.Name = "sts_tasikmalaya";
            treeNode19.Text = "Stasiun Tasikmalaya";
            treeNode20.Name = "kota_tasikmalaya";
            treeNode20.Text = "Kota Tasikmalaya";
            treeNode21.Name = "sts_ciamis";
            treeNode21.Text = "Stasiun Ciamis";
            treeNode22.Name = "kab_ciamis";
            treeNode22.Text = "Kabupaten Ciamis";
            treeNode23.Name = "sts_banjar";
            treeNode23.Text = "Stasiun Banjar";
            treeNode24.Name = "kab_banjar";
            treeNode24.Text = "Kabupaten Banjar";
            treeNode25.Name = "sts_sukabumi";
            treeNode25.Text = "Stasiun Sukabumi";
            treeNode26.Name = "sts_cicurug";
            treeNode26.Text = "Stasiun Cicurug";
            treeNode27.Name = "sts_cibadak";
            treeNode27.Text = "Stasiun Cibadak";
            treeNode28.Name = "sts_parangkuda";
            treeNode28.Text = "Stasiun Parakuda";
            treeNode29.Name = "kab_sukabumi";
            treeNode29.Text = "Kabupaten Sukabumi";
            treeNode30.Name = "sts_purwakarta";
            treeNode30.Text = "Stasiun Purwakarta";
            treeNode31.Name = "kab_purwakarta";
            treeNode31.Text = "Kabupaten Purwakarta";
            treeNode32.Name = "sts_karawang";
            treeNode32.Text = "Stasiun Karawang";
            treeNode33.Name = "sts_klari";
            treeNode33.Text = "Stasiun Klari";
            treeNode34.Name = "kab_karawang";
            treeNode34.Text = "Kabupaten Karawang";
            treeNode35.Name = "sts_bekasi";
            treeNode35.Text = "Stasiun Bekasi";
            treeNode36.Name = "sts_cikarang";
            treeNode36.Text = "Stasiun Cikarang";
            treeNode37.Name = "kab_kota_bekasi";
            treeNode37.Text = "Kabupaten Bekasi dan Kota Bekasi";
            treeNode38.Name = "sts_pagedanbaru";
            treeNode38.Text = "Stasiun Pagedanbaru";
            treeNode39.Name = "kab_subang";
            treeNode39.Text = "Kabupaten Subang";
            treeNode40.Name = "sts_haurgeulis";
            treeNode40.Text = "Stasiun Haurgeulis";
            treeNode41.Name = "sts_jatibarang";
            treeNode41.Text = "Stasiun Jatibarang";
            treeNode42.Name = "kab_indramayu";
            treeNode42.Text = "Kabupaten Indramayu";
            treeNode43.Name = "sts_cikampek";
            treeNode43.Text = "Stasiun Cikampek";
            treeNode44.Name = "sts_kadipaten";
            treeNode44.Text = "Stasiun Kadipaten";
            treeNode45.Name = "kab_majalengka";
            treeNode45.Text = "Kabupaten Majalengka";
            treeNode46.Name = "sts_cirebon";
            treeNode46.Text = "Stasiun Cirebon";
            treeNode47.Name = "sts_cirebon_pujakan";
            treeNode47.Text = "Stasiun Cirebon Pujakan";
            treeNode48.Name = "sts_babakan";
            treeNode48.Text = "Stasiun Babakan";
            treeNode49.Name = "kab_cirebon";
            treeNode49.Text = "Kabupaten Cirebon";
            treeView2.Nodes.AddRange(new TreeNode[] { treeNode3, treeNode5, treeNode8, treeNode10, treeNode14, treeNode18, treeNode20, treeNode22, treeNode24, treeNode29, treeNode31, treeNode34, treeNode37, treeNode39, treeNode42, treeNode45, treeNode49 });
            treeView2.Size = new Size(237, 154);
            treeView2.TabIndex = 12;
            treeView2.AfterSelect += treeView2_AfterSelect;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(269, 38);
            label4.Name = "label4";
            label4.Size = new Size(104, 20);
            label4.TabIndex = 9;
            label4.Text = "Stasiun Tujuan";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(15, 38);
            label3.Name = "label3";
            label3.Size = new Size(88, 20);
            label3.TabIndex = 7;
            label3.Text = "Stasiun Asal";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(269, 274);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(150, 27);
            numericUpDown1.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(269, 251);
            label2.Name = "label2";
            label2.Size = new Size(137, 20);
            label2.TabIndex = 5;
            label2.Text = "Jumlah Penumpang";
            // 
            // treeView1
            // 
            treeView1.Location = new Point(15, 61);
            treeView1.Name = "treeView1";
            treeNode50.Name = "sts_bandung";
            treeNode50.Text = "Stasiun Bandung";
            treeNode51.Name = "sts_kiaracondong";
            treeNode51.Text = "Stasiun Kiaracondong";
            treeNode52.Name = "kota_bandung";
            treeNode52.Text = "Kota Bandung";
            treeNode53.Name = "sts_padalarang";
            treeNode53.Text = "Stasiun Padalarang";
            treeNode54.Name = "kab_bandung_barat";
            treeNode54.Text = "Kabupaten Bandung Barat";
            treeNode55.Name = "sts_rancaekek";
            treeNode55.Text = "Stasiun Rancaekek";
            treeNode56.Name = "sts_cicalengka";
            treeNode56.Text = "Stasiun Cicalengka";
            treeNode57.Name = "kab_bandung";
            treeNode57.Text = "Kabupaten Bandung";
            treeNode58.Name = "sts_cimahi";
            treeNode58.Text = "Stasiun Cimahi";
            treeNode59.Name = "kota_cimahi";
            treeNode59.Text = "Kota Cimahi";
            treeNode60.Name = "sts_cianjur";
            treeNode60.Text = "Stasiun Cianjur";
            treeNode61.Name = "sts_ciranjang";
            treeNode61.Text = "Stasiun Ciranjang";
            treeNode62.Name = "sts_lampengan";
            treeNode62.Text = "Stasiun Lampengan";
            treeNode63.Name = "kab_cianjur";
            treeNode63.Text = "Kabupaten Cianjur";
            treeNode64.Name = "sts_garut";
            treeNode64.Text = "Stasiun Garut";
            treeNode65.Name = "sts_cibatu";
            treeNode65.Text = "Stasiun Cibatu";
            treeNode66.Name = "sts_karangsari";
            treeNode66.Text = "Stasiun Karangsari";
            treeNode67.Name = "kab_garut";
            treeNode67.Text = "Kabupaten Garut";
            treeNode68.Name = "sts_tasikmalaya";
            treeNode68.Text = "Stasiun Tasikmalaya";
            treeNode69.Name = "kota_tasikmalaya";
            treeNode69.Text = "Kota Tasikmalaya";
            treeNode70.Name = "sts_ciamis";
            treeNode70.Text = "Stasiun Ciamis";
            treeNode71.Name = "kab_ciamis";
            treeNode71.Text = "Kabupaten Ciamis";
            treeNode72.Name = "sts_banjar";
            treeNode72.Text = "Stasiun Banjar";
            treeNode73.Name = "kab_banjar";
            treeNode73.Text = "Kabupaten Banjar";
            treeNode74.Name = "sts_sukabumi";
            treeNode74.Text = "Stasiun Sukabumi";
            treeNode75.Name = "sts_cicurug";
            treeNode75.Text = "Stasiun Cicurug";
            treeNode76.Name = "sts_cibadak";
            treeNode76.Text = "Stasiun Cibadak";
            treeNode77.Name = "sts_parangkuda";
            treeNode77.Text = "Stasiun Parakuda";
            treeNode78.Name = "kab_sukabumi";
            treeNode78.Text = "Kabupaten Sukabumi";
            treeNode79.Name = "sts_purwakarta";
            treeNode79.Text = "Stasiun Purwakarta";
            treeNode80.Name = "kab_purwakarta";
            treeNode80.Text = "Kabupaten Purwakarta";
            treeNode81.Name = "sts_karawang";
            treeNode81.Text = "Stasiun Karawang";
            treeNode82.Name = "sts_klari";
            treeNode82.Text = "Stasiun Klari";
            treeNode83.Name = "kab_karawang";
            treeNode83.Text = "Kabupaten Karawang";
            treeNode84.Name = "sts_bekasi";
            treeNode84.Text = "Stasiun Bekasi";
            treeNode85.Name = "sts_cikarang";
            treeNode85.Text = "Stasiun Cikarang";
            treeNode86.Name = "kab_kota_bekasi";
            treeNode86.Text = "Kabupaten Bekasi dan Kota Bekasi";
            treeNode87.Name = "sts_pagedanbaru";
            treeNode87.Text = "Stasiun Pagedanbaru";
            treeNode88.Name = "kab_subang";
            treeNode88.Text = "Kabupaten Subang";
            treeNode89.Name = "sts_haurgeulis";
            treeNode89.Text = "Stasiun Haurgeulis";
            treeNode90.Name = "sts_jatibarang";
            treeNode90.Text = "Stasiun Jatibarang";
            treeNode91.Name = "kab_indramayu";
            treeNode91.Text = "Kabupaten Indramayu";
            treeNode92.Name = "sts_cikampek";
            treeNode92.Text = "Stasiun Cikampek";
            treeNode93.Name = "sts_kadipaten";
            treeNode93.Text = "Stasiun Kadipaten";
            treeNode94.Name = "kab_majalengka";
            treeNode94.Text = "Kabupaten Majalengka";
            treeNode95.Name = "sts_cirebon";
            treeNode95.Text = "Stasiun Cirebon";
            treeNode96.Name = "sts_cirebon_pujakan";
            treeNode96.Text = "Stasiun Cirebon Pujakan";
            treeNode97.Name = "sts_babakan";
            treeNode97.Text = "Stasiun Babakan";
            treeNode98.Name = "kab_cirebon";
            treeNode98.Text = "Kabupaten Cirebon";
            treeView1.Nodes.AddRange(new TreeNode[] { treeNode52, treeNode54, treeNode57, treeNode59, treeNode63, treeNode67, treeNode69, treeNode71, treeNode73, treeNode78, treeNode80, treeNode83, treeNode86, treeNode88, treeNode91, treeNode94, treeNode98 });
            treeView1.Size = new Size(237, 154);
            treeView1.TabIndex = 4;
            treeView1.AfterSelect += treeView1_AfterSelect;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 251);
            label1.Name = "label1";
            label1.Size = new Size(165, 20);
            label1.TabIndex = 3;
            label1.Text = "Tanggal Keberangkatan";
            // 
            // button_back
            // 
            button_back.Location = new Point(21, 406);
            button_back.Name = "button_back";
            button_back.Size = new Size(94, 29);
            button_back.TabIndex = 4;
            button_back.Text = "Back";
            button_back.UseVisualStyleBackColor = true;
            button_back.Click += button_back_Click;
            // 
            // cari_tiket
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(894, 458);
            Controls.Add(button_back);
            Controls.Add(groupBox1);
            Controls.Add(button_close);
            Controls.Add(pictureBox1);
            Name = "cari_tiket";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tubes Alpro - Aplikasi Tiket Kereta Jawa Barat";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button_close;
        private GroupBox groupBox1;
        private Label label1;
        private Label label2;
        private Label label4;
        private Label label3;
        private Button button_cari_tiket;
        private Button button_back;
        private System.Drawing.Printing.PrintDocument printDocument1;
        public DateTimePicker dateTimePicker1;
        public TreeView treeView1;
        public NumericUpDown numericUpDown1;
        public TreeView treeView2;
        public TextBox textBox2;
        public TextBox textBox1;
    }
}