﻿namespace Tubes_Alpro
{
    public partial class informasi_tiket : Form
    {
        private string stasiun_asal_0808;
        private string stasiun_tujuan_0808;
        private string tanggalString_0808;
        private string jumlah_0808;
        private string angkaString_0808;
        public informasi_tiket(string asal, string tujuan, string tanggal, string penumpang, string angka)
        {
            InitializeComponent();

            stasiun_asal_0808 = asal;
            stasiun_tujuan_0808 = tujuan;
            tanggalString_0808 = tanggal;
            jumlah_0808 = penumpang;
            angkaString_0808 = angka;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font font_0808 = new Font("Arial", 12);
            Brush brush_0808 = Brushes.Black;

            float startX_0808 = 100;
            float startY_0808 = 100;
            float lineHeight_0808 = font_0808.GetHeight(e.Graphics);

            e.Graphics.DrawString("Tugas Besar Algoritma & Pemrograman - Kelompok 8", font_0808, brush_0808, new PointF(startX_0808, startY_0808));
            e.Graphics.DrawString("", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + lineHeight_0808));
            e.Graphics.DrawString($"Stasiun Asal    : {stasiun_asal_0808}", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + 2 * lineHeight_0808));
            e.Graphics.DrawString($"Stasiun Tujuan  : {stasiun_tujuan_0808}", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + 3 * lineHeight_0808));
            e.Graphics.DrawString($"Tanggal Keberangkatan   : {tanggalString_0808}", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + 4 * lineHeight_0808));
            e.Graphics.DrawString($"Jumlah Penumpang    : {jumlah_0808} Orang", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + 5 * lineHeight_0808));
            e.Graphics.DrawString($"Kode Tiket  : {angkaString_0808}", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + 6 * lineHeight_0808));
            e.Graphics.DrawString("------------------------------------------------", font_0808, brush_0808, new PointF(startX_0808, startY_0808 + 7 * lineHeight_0808));

        }

        private void button1_Click(object sender, EventArgs e)
        {
            printDocument1.PrinterSettings.PrinterName = "Microsoft Print to PDF";

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "PDF Files|*.pdf",
                Title = "Save PDF File"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument1.PrinterSettings.PrintFileName = saveFileDialog.FileName;
                printDocument1.PrinterSettings.PrintToFile = true;

                // Mencetak dokumen
                printDocument1.Print();
                MessageBox.Show("Tiket berhasil dicetak di: " + saveFileDialog.FileName);
            }
        }
    }
}
