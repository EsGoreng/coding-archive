using Microsoft.Data.SqlClient;
namespace Tubes_Alpro
{
    public partial class menu_utama : Form
    {
        public menu_utama()
        {
            InitializeComponent();
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            SqlConnection con_0808 = new SqlConnection("Data Source=LAPTOP-3AFPOK6N;Initial Catalog=loginapp;Integrated Security=True;Trust Server Certificate=True");
            con_0808.Open();
            string query_0808 = "SELECT COUNT(*) FROM loginapp WHERE username=@username AND password=@password";
            SqlCommand cmd_0808 = new SqlCommand(query_0808, con_0808);
            cmd_0808.Parameters.AddWithValue("@username", user_textBox.Text);
            cmd_0808.Parameters.AddWithValue("@password", pass_textBox.Text);
            int count_0808 = (int)cmd_0808.ExecuteScalar();
            con_0808.Close();
            if (count_0808 > 0)
            {
                MessageBox.Show("Login Succes !! ", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cari_tiket f2_0808 = new cari_tiket();
                f2_0808.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Login Failed!!");
            }

        }

        private void cancel_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                pass_textBox.UseSystemPasswordChar = false;
            }
            else
            {
                pass_textBox.UseSystemPasswordChar = true;
            }
        }

        private void register_button_Click(object sender, EventArgs e)
        {
            menu_registrasi f3_0808 = new menu_registrasi();
            f3_0808.Show();
            Visible = false;
        }
    }
}
