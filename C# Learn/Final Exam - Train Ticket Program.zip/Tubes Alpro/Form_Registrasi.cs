﻿using Microsoft.Data.SqlClient;

namespace Tubes_Alpro
{
    public partial class menu_registrasi : Form
    {
        public menu_registrasi()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con_0808 = new SqlConnection("Data Source=LAPTOP-3AFPOK6N;Initial Catalog=loginapp;Integrated Security=True;Trust Server Certificate=True");
            con_0808.Open();
            string query_0808 = "INSERT INTO loginapp (nama, email, no_handphone, username, password) VALUES (@nama, @email, @no_handphone, @username, @password)";
            SqlCommand cmd_0808 = new SqlCommand(query_0808, con_0808);
            cmd_0808.Parameters.AddWithValue("@nama", nama_textBox.Text);
            cmd_0808.Parameters.AddWithValue("@email", email_textBox.Text);
            cmd_0808.Parameters.AddWithValue("@no_handphone", nohp_textBox.Text);
            cmd_0808.Parameters.AddWithValue("@username", userReg_textBox.Text);
            cmd_0808.Parameters.AddWithValue("@password", passReg_textBox.Text);
            int rowsAffected_0808 = cmd_0808.ExecuteNonQuery();
            con_0808.Close();
            if (rowsAffected_0808 > 0)
            {
                MessageBox.Show("Registrasi Berhasil !!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                menu_utama f1_0808 = new menu_utama();
                f1_0808.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Registrasi Gagal", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
            
        private void button2_Click(object sender, EventArgs e)
        {
            menu_utama f1_0808 = new menu_utama();
            f1_0808.Show();
            Visible = false;
        }
    }
}
