public class App {
    public static void main(String[] args) throws Exception {
        int nilai_0056 = 1;
        while (nilai_0056 <= 5){
            System.out.println(nilai_0056);
            nilai_0056++;
        }

    }
}
