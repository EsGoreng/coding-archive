nilai_0056 = 1;
while (nilai_0056 <= 5):
    print(nilai_0056)
    nilai_0056+=1
