﻿int input_0056 = 1;
while (input_0056 <= 5) {
    Console.WriteLine(input_0056);
    input_0056++;
}