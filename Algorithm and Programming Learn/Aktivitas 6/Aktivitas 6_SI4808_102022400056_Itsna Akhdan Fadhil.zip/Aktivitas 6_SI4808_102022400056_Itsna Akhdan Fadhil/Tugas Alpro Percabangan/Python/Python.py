"""
Nama  : Itsna Akhdan Fadhil
NIM   : 102022400056
Kelas : SI-48-08
"""
print("///// Program Input Nilaii /////")
print("")
input_nilai_0056 = int(input("Masukan Input : "))
print("")
if input_nilai_0056 >= 60:
    print("Lulus")
else:
    print("Tidak Lulus")

if input_nilai_0056 >= 90:
    print("Grade : A")
elif input_nilai_0056 >= 80:
    print("Grade : AB")
elif input_nilai_0056 >= 70:
    print("Grade : C")
elif input_nilai_0056 >= 60:
    print("Grade : C")
else:
    print("Grade : D")
print("")
print("////////////////////////////////")



