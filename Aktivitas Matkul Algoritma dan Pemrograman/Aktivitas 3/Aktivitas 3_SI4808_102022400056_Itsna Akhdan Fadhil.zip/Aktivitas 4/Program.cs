﻿//Itsna Akhdan Fadhil - 102022400056

int terbesar_0056;

    if (85 > 75 && 85 > 65) {
        terbesar_0056 = 85;
    }
    else if (75 > 65) {
        terbesar_0056 = 75;
    }
    else if (85 == terbesar_0056) {
        Console.Write("85 adalah terbesar");
    }
    else {
        Console.Write("85 bukan yang terbesar");
    }